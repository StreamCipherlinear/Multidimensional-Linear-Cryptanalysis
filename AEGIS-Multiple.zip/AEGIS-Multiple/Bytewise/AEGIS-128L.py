from coptpy import *
import time

env = Envr()
model = env.createModel("AEGIS-128L_Sbox") 
model.setParam(COPT.Param.HeurLevel, 3)
model.setParam("Logging", 0)

Num = model.addVar(vtype=COPT.INTEGER)

# 6 
alpha0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
alpha1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)

# 18
a0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
a1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
e0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
e1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
f0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
f1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
g = model.addVars(list(range(16)), vtype = COPT.BINARY)
h = model.addVars(list(range(16)), vtype = COPT.BINARY)
l = model.addVars(list(range(16)), vtype = COPT.BINARY)
m = model.addVars(list(range(16)), vtype = COPT.BINARY)
n = model.addVars(list(range(16)), vtype = COPT.BINARY)
p = model.addVars(list(range(16)), vtype = COPT.BINARY)

# 14
f0gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
e0gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
gbeta0gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
mbeta1gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
galpha0beta0gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
malpha1beta1gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d0f0nbeta0gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0e0hbeta1gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0d0f0nalpha0beta0gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
a0c0e0halpha1beta1gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c1e1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d1f1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
a1c1e1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b1d1f1 = model.addVars(list(range(16)), vtype = COPT.BINARY)

gbeta0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
mbeta1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta0gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta1gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
alpha0beta0gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
alpha1beta1gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d0n = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0h = model.addVars(list(range(16)), vtype = COPT.BINARY)
d0f0n = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0e0h = model.addVars(list(range(16)), vtype = COPT.BINARY)
d0f0ng = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0e0hm = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0d0f0n = model.addVars(list(range(16)), vtype = COPT.BINARY)
a0c0e0h = model.addVars(list(range(16)), vtype = COPT.BINARY)
d0nbeta0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0hbeta1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d0f0nbeta0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0e0hbeta1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0d0f0nbeta0gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
a0c0e0hbeta1gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)

ind   = model.addVars(list(range(56)), vtype = COPT.BINARY)
number = model.addVars(list(range(16)), vtype=COPT.INTEGER)

A1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A2 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A3 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A4 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A5 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A6 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A7 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A8 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A9 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A10 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A11 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A12 = model.addVars(list(range(16)), vtype = COPT.BINARY)

Z1 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z2 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z3 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z4 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z5 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z6 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z7 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z8 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z9 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z10 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z11 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z12 = model.addVars(list(range(4)), vtype = COPT.BINARY)

def sigleMC(vindex, dindex):
    model.addConstr(sum(vindex) - 5 * dindex >= 0)
    for item in vindex:
        model.addConstr(dindex >= item)

def AESRound(inp, outp, dex):
    sigleMC([inp[0],  inp[5],  inp[10], inp[15], outp[0],  outp[1],  outp[2],   outp[3]],  ind[dex])
    sigleMC([inp[4],  inp[9],  inp[14], inp[3],  outp[4],  outp[5],  outp[6],    outp[7]],   ind[dex + 1])
    sigleMC([inp[8],  inp[13], inp[2],  inp[7],  outp[8],  outp[9],  outp[10],   outp[11]],  ind[dex + 2])
    sigleMC([inp[12], inp[1],  inp[6],  inp[11], outp[12], outp[13], outp[14],   outp[15]],  ind[dex + 3])
    
def xor(inp1, inp2, out):
    model.addConstr(inp1 + inp2 - out >= 0)
    model.addConstr(inp1 - inp2 + out >= 0)
    model.addConstr(-inp1 + inp2 + out >= 0)

def And(inp1, inp2, out):
    model.addConstr(out - inp1 >= 0)
    model.addConstr(out - inp2 >= 0)

def fun(inp0, inp1, diff, A, Z):
    for i in range(16): 
        xor(inp0[i], inp1[i], A[i])      
    for i in range(4):
        model.addGenConstrOr(Z[i], [diff[4*i], diff[4*i+1], diff[4*i+2], diff[4*i+3]])
        model.addGenConstrIndicator(Z[i], 0, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] == 0)
        model.addGenConstrIndicator(Z[i], 1, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] + diff[4*i] + diff[4*i+1] + diff[4*i+2] + diff[4*i+3] >= 5)

def modeling():
    start_time = time.perf_counter()
    for i in range(16):
        xor(f0[i], gamma0[i], f0gamma0[i])
        xor(e0[i], gamma1[i], e0gamma1[i])
        xor(g[i], beta0[i], gbeta0[i])
        xor(m[i], beta1[i], mbeta1[i])
        xor(beta0[i], gamma0[i], beta0gamma0[i])
        xor(beta1[i], gamma1[i], beta1gamma1[i])
        xor(gbeta0[i], gamma0[i], gbeta0gamma0[i])
        xor(mbeta1[i], gamma1[i], mbeta1gamma1[i])
        xor(g[i], beta0gamma0[i], gbeta0gamma0[i])
        xor(m[i], beta1gamma1[i], mbeta1gamma1[i])
        xor(gbeta0gamma0[i], alpha0[i], galpha0beta0gamma0[i])
        xor(mbeta1gamma1[i], alpha1[i], malpha1beta1gamma1[i])
        xor(g[i], alpha0beta0gamma0[i], galpha0beta0gamma0[i])
        xor(m[i], alpha1beta1gamma1[i], malpha1beta1gamma1[i])
        xor(n[i], d0[i], d0n[i])
        xor(h[i], c0[i], c0h[i])
        xor(d0n[i], f0[i], d0f0n[i])
        xor(c0h[i], e0[i], c0e0h[i])
        xor(d0f0n[i], g[i], d0f0ng[i])
        xor(c0e0h[i], m[i], c0e0hm[i])
        xor(b0[i], d0f0n[i], b0d0f0n[i])
        xor(a0[i], c0e0h[i], a0c0e0h[i])
        xor(d0n[i], beta0[i], d0nbeta0[i])
        xor(c0h[i], beta1[i], c0hbeta1[i])
        xor(d0nbeta0[i], f0[i], d0f0nbeta0[i])
        xor(c0hbeta1[i], e0[i], c0e0hbeta1[i])
        xor(d0f0n[i], beta0gamma0[i], d0f0nbeta0gamma0[i])
        xor(c0e0h[i], beta1gamma1[i], c0e0hbeta1gamma1[i])
        xor(f0gamma0[i], d0nbeta0[i], d0f0nbeta0gamma0[i])
        xor(e0gamma1[i], c0hbeta1[i], c0e0hbeta1gamma1[i])
        xor(d0f0nbeta0[i], gamma0[i], d0f0nbeta0gamma0[i])
        xor(c0e0hbeta1[i], gamma1[i], c0e0hbeta1gamma1[i])
        xor(d0f0nbeta0gamma0[i], b0[i], b0d0f0nbeta0gamma0[i])
        xor(c0e0hbeta1gamma1[i], a0[i], a0c0e0hbeta1gamma1[i])
        xor(b0d0f0n[i], beta0gamma0[i], b0d0f0nbeta0gamma0[i])
        xor(a0c0e0h[i], beta1gamma1[i], a0c0e0hbeta1gamma1[i])
        xor(b0d0f0nbeta0gamma0[i], alpha0[i], b0d0f0nalpha0beta0gamma0[i])
        xor(a0c0e0hbeta1gamma1[i], alpha1[i], a0c0e0halpha1beta1gamma1[i])
        xor(b0d0f0n[i], alpha0beta0gamma0[i], b0d0f0nalpha0beta0gamma0[i])
        xor(a0c0e0h[i], alpha1beta1gamma1[i], a0c0e0halpha1beta1gamma1[i])
        
        xor(c1[i], e1[i], c1e1[i])
        xor(d1[i], f1[i], d1f1[i])
        xor(c1e1[i], a1[i], a1c1e1[i])
        xor(d1f1[i], b1[i], b1d1f1[i])

    # &
    for i in range(16):
        And(a0[i], a1[i], alpha0[i])
        And(b0[i], b1[i], alpha1[i])
        And(c0[i], c1[i], beta0[i])
        And(d0[i], d1[i], beta1[i])
        And(e0[i], e1[i], gamma0[i])
        And(f0[i], f1[i], gamma1[i])
    
    # branch
    AESRound(m, f0gamma0, 0)
    AESRound(g, e0gamma1, 4)
    AESRound(h, e1, 8)
    AESRound(n, f1, 12)
    AESRound(p, gamma0, 16)
    AESRound(l, gamma1, 20)
    AESRound(p, gbeta0gamma0, 24)
    AESRound(l, mbeta1gamma1, 28)
    AESRound(malpha1beta1gamma1, d0f0nbeta0gamma0, 32)
    AESRound(galpha0beta0gamma0, c0e0hbeta1gamma1, 36)
    AESRound(b1d1f1, p, 40)
    AESRound(a1c1e1, l, 44)
    AESRound(a0c0e0halpha1beta1gamma1, c1e1, 48)
    AESRound(b0d0f0nalpha0beta0gamma0, d1f1, 52)
    
    
    # outer masks
    t = 0
    for i in range(16):
        t = t + alpha0[i] + alpha1[i] + beta0[i] + beta1[i] + gamma0[i] + gamma1[i]
    model.addConstr(t >= 1)

    # break the gap
    fun(m, p, f0, A1, Z1)
    fun(m, malpha1beta1gamma1, d0nbeta0, A2, Z2)
    fun(p, p, gbeta0, A3, Z3)
    fun(p, malpha1beta1gamma1, d0f0nbeta0, A4, Z4)
    fun(h, a0c0e0halpha1beta1gamma1, c1, A5, Z5)

    fun(g, l, e0, A6, Z6)
    fun(g, galpha0beta0gamma0, c0hbeta1, A7, Z7)
    fun(l, l, mbeta1, A8, Z8)
    fun(l, galpha0beta0gamma0, c0e0hbeta1, A9, Z9)
    fun(n, b0d0f0nalpha0beta0gamma0, d1, A10, Z10)

    fun(p, malpha1beta1gamma1, d0f0ng, A11, Z11)
    fun(l, galpha0beta0gamma0, c0e0hm, A12, Z12)
        
    # Minimum S-boxes
    for i in range(16):
        model.addConstr(number[i] == g[i] + h[i] + 2 * l[i] + m[i] + n[i] + 2 * p[i] + malpha1beta1gamma1[i] + galpha0beta0gamma0[i] + b1d1f1[i] + a1c1e1[i] + a0c0e0halpha1beta1gamma1[i] + b0d0f0nalpha0beta0gamma0[i])

    model.addConstr(Num == sum(number[i] for i in range(16)))
    
    # Objective Function
    obj = 0 
    for i in range(16):
        obj = obj + 7 * number[i] + 2 * (alpha0[i] + alpha1[i] + beta0[i] + beta1[i] + gamma0[i] + gamma1[i])
    
    model.setObjective(obj, COPT.MINIMIZE)
    model.solve()

    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"Running time：{execution_time:.6f} seconds")
    
    if model.status == COPT.OPTIMAL:
        print("Objective value: {}".format(model.objval))
        allvars = model.getVars()
        print("Variable solution:")
        for var in allvars:
            print(" {0}: {1}".format(var.index, var.x))

    
 
modeling()    
