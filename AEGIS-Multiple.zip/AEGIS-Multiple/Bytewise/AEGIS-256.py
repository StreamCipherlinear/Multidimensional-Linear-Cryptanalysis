from coptpy import *
import time

env = Envr()
model = env.createModel("AEGIS-256_Sbox") 
model.setParam(COPT.Param.HeurLevel, 3)
model.setParam("Logging", 0)

Num = model.addVar(vtype=COPT.INTEGER)

alpha = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma = model.addVars(list(range(16)), vtype = COPT.BINARY)

a0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
a1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d = model.addVars(list(range(16)), vtype = COPT.BINARY)
e = model.addVars(list(range(16)), vtype = COPT.BINARY)
f = model.addVars(list(range(16)), vtype = COPT.BINARY)
g = model.addVars(list(range(16)), vtype = COPT.BINARY)
h = model.addVars(list(range(16)), vtype = COPT.BINARY)

gbetagamma = model.addVars(list(range(16)), vtype = COPT.BINARY) 
galphabetagamma = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0c0h = model.addVars(list(range(16)), vtype = COPT.BINARY)
a0b0c0h =model.addVars(list(range(16)), vtype = COPT.BINARY)
b1c1e = model.addVars(list(range(16)), vtype = COPT.BINARY)
a1b1c1e =model.addVars(list(range(16)), vtype = COPT.BINARY) 
fbetagamma =model.addVars(list(range(16)), vtype = COPT.BINARY)
betagamma =model.addVars(list(range(16)), vtype = COPT.BINARY)
falphabetagamma =model.addVars(list(range(16)), vtype = COPT.BINARY)
alphabetagamma =model.addVars(list(range(16)), vtype = COPT.BINARY)

gbeta = model.addVars(list(range(16)), vtype = COPT.BINARY)
fbeta = model.addVars(list(range(16)), vtype = COPT.BINARY) 
b1e = model.addVars(list(range(16)), vtype = COPT.BINARY) 
b0h = model.addVars(list(range(16)), vtype = COPT.BINARY) 

ind   = model.addVars(list(range(44)), vtype = COPT.BINARY)
number = model.addVars(list(range(16)), vtype=COPT.INTEGER)

A1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A2 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A3 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A4 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A5 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A6 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A7 = model.addVars(list(range(16)), vtype = COPT.BINARY)

Z1 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z2 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z3 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z4 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z5 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z6 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z7 = model.addVars(list(range(4)), vtype = COPT.BINARY)

def sigleMC(vindex, dindex):
    model.addConstr(sum(vindex) - 5 * dindex >= 0)
    for item in vindex:
        model.addConstr(dindex >= item)

def AESRound(inp, outp, dex):
    sigleMC([inp[0],  inp[5],  inp[10], inp[15], outp[0],  outp[1],  outp[2],   outp[3]],  ind[dex])
    sigleMC([inp[4],  inp[9],  inp[14], inp[3],  outp[4],  outp[5],  outp[6],    outp[7]],   ind[dex + 1])
    sigleMC([inp[8],  inp[13], inp[2],  inp[7],  outp[8],  outp[9],  outp[10],   outp[11]],  ind[dex + 2])
    sigleMC([inp[12], inp[1],  inp[6],  inp[11], outp[12], outp[13], outp[14],   outp[15]],  ind[dex + 3])
    
def xor(inp1, inp2, out):
    model.addConstr(inp1 + inp2 - out >= 0)
    model.addConstr(inp1 - inp2 + out >= 0)
    model.addConstr(-inp1 + inp2 + out >= 0)

def And(inp1, inp2, out):
    model.addConstr(out - inp1 >= 0)
    model.addConstr(out - inp2 >= 0)

def fun(inp0, inp1, diff, A, Z):
    for i in range(16): 
        xor(inp0[i], inp1[i], A[i])      
    for i in range(4):
        model.addGenConstrOr(Z[i], [diff[4*i], diff[4*i+1], diff[4*i+2], diff[4*i+3]])
        model.addGenConstrIndicator(Z[i], 0, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] == 0)
        model.addGenConstrIndicator(Z[i], 1, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] + diff[4*i] + diff[4*i+1] + diff[4*i+2] + diff[4*i+3] >= 5)

def modeling():
    start_time = time.perf_counter()
    for i in range(16):
        xor(beta[i], g[i], gbeta[i])
        xor(beta[i], gamma[i], betagamma[i])
        xor(gbeta[i], gamma[i], gbetagamma[i])
        xor(g[i], betagamma[i], gbetagamma[i])
        xor(alpha[i], betagamma[i], alphabetagamma[i])
        xor(alpha[i], gbetagamma[i], galphabetagamma[i])
        xor(g[i], alphabetagamma[i], galphabetagamma[i])

        xor(beta[i], f[i], fbeta[i])
        xor(fbeta[i], gamma[i], fbetagamma[i])
        xor(f[i], betagamma[i], fbetagamma[i])
        xor(f[i], alphabetagamma[i], falphabetagamma[i])
        xor(alpha[i], fbetagamma[i], falphabetagamma[i])

        xor(b0[i], h[i], b0h[i])
        xor(b0h[i], c0[i], b0c0h[i])
        xor(a0[i], b0c0h[i], a0b0c0h[i])
        xor(b1[i], e[i], b1e[i])
        xor(b1e[i], c1[i], b1c1e[i])
        xor(a1[i], b1c1e[i], a1b1c1e[i])

    # &
    for i in range(16):
        And(a0[i], a1[i], alpha[i])
        And(b0[i], b1[i], beta[i])
        And(c0[i], c1[i], gamma[i])
    
    # branch
    AESRound(d, gamma, 0)
    AESRound(e, gamma, 4)
    AESRound(f, gamma, 8)
    AESRound(g, c0, 12)
    AESRound(h, c1, 16)
    AESRound(d, gbetagamma, 20)
    AESRound(galphabetagamma, b0c0h, 24)
    AESRound(a0b0c0h, b1c1e, 28)
    AESRound(a1b1c1e, fbetagamma, 32)
    AESRound(falphabetagamma, betagamma, 36)
    AESRound(alphabetagamma, d, 40)
    
    # outer masks
    t = 0
    for i in range(16):
        t = t + alpha[i] + beta[i] + gamma[i]
    model.addConstr(t >= 1)

    # break the gap
    fun(d, d, gbeta,  A1, Z1)
    fun(d, a1b1c1e, fbeta, A2, Z2)
    fun(d, falphabetagamma, beta, A3, Z3)
    fun(d, falphabetagamma, g, A4, Z4)
    fun(a1b1c1e, falphabetagamma, f, A5, Z5)
    fun(h, a0b0c0h, b1e, A6, Z6)
    fun(g, galphabetagamma, b0h, A7, Z7)
    for i in range(16):
        model.addConstr(d[i] == e[i])
        model.addConstr(d[i] == f[i])
        
    # Minimum S-boxes
    for i in range(16):
        model.addConstr(number[i] == d[i] + e[i] + f[i] + g[i] + h[i] + d[i] + galphabetagamma[i] + a0b0c0h[i] +a1b1c1e[i] + falphabetagamma[i] + alphabetagamma[i])

    model.addConstr(Num == sum(number[i] for i in range(16)))
    
    # Objective Function
    obj = 0 
    for i in range(16):
        obj = obj +  6 * (d[i] + e[i] + f[i] + g[i] + h[i] + d[i] + galphabetagamma[i] + a0b0c0h[i] +a1b1c1e[i] + falphabetagamma[i] + alphabetagamma[i]) + 2 * alpha[i] + 2 * beta[i] + 2 * gamma[i]
    
    model.setObjective(obj, COPT.MINIMIZE)
    model.solve()

    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"Running time：{execution_time:.6f} seconds")
    
    if model.status == COPT.OPTIMAL:
        print("Objective value: {}".format(model.objval))
        allvars = model.getVars()
        print("Variable solution:")
        for var in allvars:
            print(" {0}: {1}".format(var.index, var.x))

    
 
modeling()    
