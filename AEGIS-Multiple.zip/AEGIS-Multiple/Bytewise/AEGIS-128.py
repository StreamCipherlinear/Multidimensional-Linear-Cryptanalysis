from coptpy import *
import time

env = Envr()
model = env.createModel("AEGIS-128_Sbox") 
model.setParam(COPT.Param.HeurLevel, 3)
model.setParam("Logging", 0)

Num = model.addVar(vtype=COPT.INTEGER)

alpha = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma = model.addVars(list(range(16)), vtype = COPT.BINARY)

a = model.addVars(list(range(16)), vtype = COPT.BINARY)
b = model.addVars(list(range(16)), vtype = COPT.BINARY)
c = model.addVars(list(range(16)), vtype = COPT.BINARY)
d = model.addVars(list(range(16)), vtype = COPT.BINARY)
e = model.addVars(list(range(16)), vtype = COPT.BINARY)
f = model.addVars(list(range(16)), vtype = COPT.BINARY)
g = model.addVars(list(range(16)), vtype = COPT.BINARY)
h = model.addVars(list(range(16)), vtype = COPT.BINARY)
l = model.addVars(list(range(16)), vtype = COPT.BINARY)
m = model.addVars(list(range(16)), vtype = COPT.BINARY)

gbetagamma = model.addVars(list(range(16)), vtype = COPT.BINARY) 
galphabetagamma = model.addVars(list(range(16)), vtype = COPT.BINARY)
ceh = model.addVars(list(range(16)), vtype = COPT.BINARY)
aceh =model.addVars(list(range(16)), vtype = COPT.BINARY)
dfl = model.addVars(list(range(16)), vtype = COPT.BINARY)
bdfl =model.addVars(list(range(16)), vtype = COPT.BINARY) 
betagamma =model.addVars(list(range(16)), vtype = COPT.BINARY)
alphabetagamma =model.addVars(list(range(16)), vtype = COPT.BINARY)

ch = model.addVars(list(range(16)), vtype = COPT.BINARY) 
dl = model.addVars(list(range(16)), vtype = COPT.BINARY) 
gbeta = model.addVars(list(range(16)), vtype = COPT.BINARY) 

ind   = model.addVars(list(range(36)), vtype = COPT.BINARY)
number = model.addVars(list(range(16)), vtype=COPT.INTEGER)

A1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A2 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A3 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A4 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A5 = model.addVars(list(range(16)), vtype = COPT.BINARY)

Z1 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z2 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z3 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z4 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Z5 = model.addVars(list(range(4)), vtype = COPT.BINARY)

def sigleMC(vindex, dindex):# 每一列的Mixcolumn
    model.addConstr(sum(vindex) - 5 * dindex >= 0)
    for item in vindex:
        model.addConstr(dindex >= item)

def AESRound(inp, outp, dex):#线性分支数的限制
    sigleMC([inp[0],  inp[5],  inp[10], inp[15], outp[0],  outp[1],  outp[2],   outp[3]],  ind[dex])
    sigleMC([inp[4],  inp[9],  inp[14], inp[3],  outp[4],  outp[5],  outp[6],    outp[7]],   ind[dex + 1])
    sigleMC([inp[8],  inp[13], inp[2],  inp[7],  outp[8],  outp[9],  outp[10],   outp[11]],  ind[dex + 2])
    sigleMC([inp[12], inp[1],  inp[6],  inp[11], outp[12], outp[13], outp[14],   outp[15]],  ind[dex + 3])
    
def xor(inp1, inp2, out):#字节级别的活跃异或运算, 1+0=0,0+1=1,0+0=0, 1+1=1或0
    model.addConstr(inp1 + inp2 - out >= 0)
    model.addConstr(inp1 - inp2 + out >= 0)
    model.addConstr(-inp1 + inp2 + out >= 0)

def And(inp1, inp2, out):
    model.addConstr(out - inp1 >= 0)
    model.addConstr(out - inp2 >= 0)

def fun(inp0, inp1, A, diff, Z):
    for i in range(16): 
        xor(inp0[i], inp1[i], A[i])      
    for i in range(4):
        model.addGenConstrOr(Z[i], [diff[4*i], diff[4*i+1], diff[4*i+2], diff[4*i+3]])
        model.addGenConstrIndicator(Z[i], 0, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] == 0)
        model.addGenConstrIndicator(Z[i], 1, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] + diff[4*i] + diff[4*i+1] + diff[4*i+2] + diff[4*i+3] >= 5)
      
def modeling():
    start_time = time.perf_counter()
    # 掩码之间的异或运算约束, 
    for i in range(16):
        xor(beta[i], g[i], gbeta[i])
        xor(beta[i], gamma[i], betagamma[i])
        xor(gbeta[i], gamma[i], gbetagamma[i])
        xor(g[i], betagamma[i], gbetagamma[i])
        xor(alpha[i], betagamma[i], alphabetagamma[i])
        xor(alpha[i], gbetagamma[i], galphabetagamma[i])
        xor(g[i], alphabetagamma[i], galphabetagamma[i])
        xor(c[i], h[i], ch[i])
        xor(e[i], ch[i], ceh[i])
        xor(a[i], ceh[i], aceh[i])
        xor(d[i], l[i], dl[i])
        xor(f[i], dl[i], dfl[i])
        xor(b[i], dfl[i], bdfl[i])

    # &
    for i in range(16):
        And(a[i], b[i], alpha[i])
        And(c[i], d[i], beta[i])
        And(e[i], f[i], gamma[i])
    
    # branch
    AESRound(g, e, 0)
    AESRound(h, f, 4)
    AESRound(l, gamma, 8)
    AESRound(m, gamma, 12)
    AESRound(m, gbetagamma, 16)
    AESRound(galphabetagamma, ceh, 20)
    AESRound(aceh, dfl, 24)
    AESRound(bdfl, betagamma, 28)
    AESRound(alphabetagamma, m, 32)
        
    # outer masks
    t = 0
    for i in range(16):
        t = t + alpha[i] + beta[i] + gamma[i]
    model.addConstr(t >= 1)

    # break the gap
    fun(g, galphabetagamma, A1, ch, Z1)
    fun(h, aceh, A2, dl, Z2)
    fun(m, m, A3, gbeta, Z3)
    fun(l, bdfl, A4, beta, Z4)
    fun(m, bdfl, A5, g, Z5)
    
    for i in range(16):
        model.addConstr(l[i] == m[i])

    # Minimum S-boxes
    for i in range(16):
        model.addConstr(number[i] == g[i] + h[i] + l[i] + m[i] + m[i] + galphabetagamma[i] + aceh[i] + bdfl[i] + alphabetagamma[i])
    model.addConstr(Num == sum(number[i] for i in range(16)))
    # Objective Function
    obj = 0 
    for i in range(16):
        obj = obj + 7 * (g[i] + h[i] + l[i] + m[i] + m[i] + galphabetagamma[i] + aceh[i] + bdfl[i] + alphabetagamma[i]) + 4 * (alpha[i] + beta[i] + gamma[i])
    
    model.setObjective(obj, COPT.MINIMIZE)
    model.solve()
    # Caculate the time
    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"Running time：{execution_time:.6f} seconds")
    
    if model.status == COPT.OPTIMAL:
        print("Objective value: {}".format(model.objval))
        allvars = model.getVars()
    
        print("Variable solution:")
        for var in allvars:
            print(" {0}: {1}".format(var.index, var.x))
 
modeling()    
