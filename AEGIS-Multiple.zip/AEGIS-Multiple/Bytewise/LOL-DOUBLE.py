from coptpy import *
import time

env = Envr()
model = env.createModel("LOLALinearSbox") 
model.setParam(COPT.Param.HeurLevel, 3)
model.setParam("Logging", 0)

alpha0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
alpha1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
beta1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
gamma1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
lam0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
lam1 = model.addVars(list(range(16)), vtype = COPT.BINARY)

a0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
a1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
b1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
c1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
d1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
e0 = model.addVars(list(range(16)), vtype = COPT.BINARY)
e1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
f0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
f1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
g0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
g1  = model.addVars(list(range(16)), vtype = COPT.BINARY)

ind   = model.addVars(list(range(80)), vtype = COPT.BINARY)

a0c0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
a1c1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
a0e0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
a1e1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
a0c0e0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
a1c1e1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0d0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
b1d1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
b1d1alpha0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0d0alpha1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
b1beta0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
b0beta1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
f0gamma0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
f1gamma1  = model.addVars(list(range(16)), vtype = COPT.BINARY)
g0beta0  = model.addVars(list(range(16)), vtype = COPT.BINARY)
g1beta1  = model.addVars(list(range(16)), vtype = COPT.BINARY)

A1 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A2 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A3 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A4 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A5 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A6 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A7 = model.addVars(list(range(16)), vtype = COPT.BINARY)
A8 = model.addVars(list(range(16)), vtype = COPT.BINARY)

Y1 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y2 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y3 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y4 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y5 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y6 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y7 = model.addVars(list(range(4)), vtype = COPT.BINARY)
Y8 = model.addVars(list(range(4)), vtype = COPT.BINARY)

def sigleMC(vindex, dindex):
    model.addConstr(sum(vindex) - 5 * dindex >= 0)
    for item in vindex:
        model.addConstr(dindex >= item)

def AESRound(inp, outp, dex):
    sigleMC([inp[0],  inp[5],  inp[10], inp[15], outp[0],  outp[1],  outp[2],   outp[3]],  ind[dex])
    sigleMC([inp[4],  inp[9],  inp[14], inp[3],  outp[4],  outp[5],  outp[6],    outp[7]],   ind[dex + 1])
    sigleMC([inp[8],  inp[13], inp[2],  inp[7],  outp[8],  outp[9],  outp[10],   outp[11]],  ind[dex + 2])
    sigleMC([inp[12], inp[1],  inp[6],  inp[11], outp[12], outp[13], outp[14],   outp[15]],  ind[dex + 3])

def xor(inp1, inp2, out):
    model.addConstr(inp1 + inp2 - out >= 0)
    model.addConstr(inp1 - inp2 + out >= 0)
    model.addConstr(-inp1 + inp2 + out >= 0)

def bitxor(inp1, inp2, out):
    model.addConstr(inp1 + inp2 - out >= 0)
    model.addConstr(inp1 - inp2 + out >= 0)
    model.addConstr(-inp1 + inp2 + out >= 0)
    model.addConstr(out <= 2 - inp1 - inp2)

def fun(inp0, inp1, diff, A, Z):
    for i in range(16):
        xor(inp0[i], inp1[i], A[i])
    for i in range(4):
        model.addGenConstrOr(Z[i], [diff[4*i], diff[4*i+1], diff[4*i+2], diff[4*i+3]])
        model.addGenConstrIndicator(Z[i], 0, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] == 0)
        model.addGenConstrIndicator(Z[i], 1, A[4*i] + A[(4*i+5)%16] + A[(4*i+10)%16] + A[(4*i+15)%16] + diff[4*i] + diff[4*i+1] + diff[4*i+2] + diff[4*i+3] >= 5)

def modeling():
    start_time = time.perf_counter()    
    for i in range(16):
        xor(a0[i], c0[i], a0c0[i])
        xor(a1[i], c1[i], a1c1[i])
        xor(a0[i], e0[i], a0e0[i])
        xor(a1[i], e1[i], a1e1[i])
        xor(a0c0[i], e0[i], a0c0e0[i])
        xor(a0e0[i], c0[i], a0c0e0[i])
        xor(a1c1[i], e1[i], a1c1e1[i])
        xor(a1e1[i], c1[i], a1c1e1[i])
        xor(b0[i], d0[i], b0d0[i])
        xor(b1[i], d1[i], b1d1[i])
        xor(b0d0[i], alpha1[i], b0d0alpha1[i])
        xor(b1d1[i], alpha0[i], b1d1alpha0[i])
        xor(b1[i], beta0[i], b1beta0[i])
        xor(b0[i], beta1[i], b0beta1[i])
        xor(f0[i], gamma0[i], f0gamma0[i])
        xor(f1[i], gamma1[i], f1gamma1[i])
        xor(g0[i], beta0[i], g0beta0[i])
        xor(g1[i], beta1[i], g1beta1[i])
    
    AESRound(a0, lam0, 0)
    AESRound(a1, lam1, 4)
    AESRound(b0, a0, 8)
    AESRound(b1, a1, 12)
    AESRound(c0, gamma0, 16)
    AESRound(c1, gamma1, 20)  
    AESRound(d0, a0c0, 24)
    AESRound(d1, a1c1, 28)
    AESRound(e0, b1d1alpha0, 32)
    AESRound(e1, b0d0alpha1, 36)
    AESRound(f0, lam0, 40)
    AESRound(f1, lam1, 44)
    AESRound(g0, f0gamma0, 48)
    AESRound(g1, f1gamma1, 52)
    AESRound(a0c0e0, b1beta0, 56)
    AESRound(a1c1e1, b0beta1, 60)
    AESRound(alpha0, g0beta0, 64)
    AESRound(alpha1, g1beta1, 68)
    AESRound(b0d0, e0, 72)
    AESRound(b1d1, e1, 76)
 
    t = 0
    for r in range(0,16):
        t = t + alpha0[r] + alpha1[r] + beta0[r] + beta1[r] + gamma0[r] + gamma1[r] + lam0[r] + lam1[r]
    model.addConstr(t >= 1)

    # break the gap
    for i in range(16):
        model.addConstr(a0[i] == f0[i])
        model.addConstr(a1[i] == f1[i])
    
    fun(b0, d0, c0, A1, Y1)
    fun(b0, b0d0, a0e0, A2, Y2)
    fun(b1, d1, c1, A3, Y3)
    fun(b1, b1d1, a1e1, A4, Y4)
    fun(c0, g0, f0, A5, Y5)
    fun(c1, g1, f1, A6, Y6)
    fun(d0, b0d0, a0c0e0, A7, Y7)
    fun(d1, b1d1, a1c1e1, A8, Y8)
        
    #Objective Function
    obj = 0 
    for r in range(0, 16):
        obj = obj + a0[r] + a1[r] + b0[r] + b1[r] + c0[r] + c1[r] + d0[r] + d1[r] + e0[r] + e1[r] + f0[r] + f1[r] + g0[r] + g1[r] + a0c0e0[r] + a1c1e1[r] + alpha0[r] + alpha1[r] + b0d0[r] + b1d1[r]

    model.setObjective(obj, COPT.MINIMIZE)
    model.solve()
    end_time = time.perf_counter()
    execution_time = end_time - start_time
    print(f"Running time：{execution_time:.6f} seconds")

    if model.status == COPT.OPTIMAL:
        print("Objective value: {}".format(model.objval))
        allvars = model.getVars()
        print("Variable solution:")
        for var in allvars:
            print(" {0}: {1}".format(var.index, var.x))
            
modeling()
