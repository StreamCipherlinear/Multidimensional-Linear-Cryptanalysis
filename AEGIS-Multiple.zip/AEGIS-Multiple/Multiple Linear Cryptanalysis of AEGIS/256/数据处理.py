import struct

def process_data(input_file):
    with open(input_file, 'r') as f:
        for line_num, line in enumerate(f, 1):  # 记录行号，便于调试
            line = line.strip()  # 去除首尾空白字符
            if not line:  # 跳过空行
                continue
            
            parts = line.split()  # 自动处理多个空格/制表符
            if len(parts) < 6:  # 需要 5 个十六进制数 + 1 个浮点数
                print(f"警告：第 {line_num} 行数据不完整，跳过: {line}")
                continue
            
            try:
                # 解析前 5 个十六进制数
                hex_values = [int(x, 16) for x in parts[:5]]  # 只取前 5 个
                a, b, c, d = hex_values[1:5]  # 提取第 2~5 个十六进制数
                
                # 计算 result_1: a ^ (b << 8) ^ (c << 16) ^ (d << 24)
                result_1 = a ^ (b << 8) ^ (c << 16) ^ (d << 24)
                
                # result_2 是第一个十六进制数
                result_2 = hex_values[0]
                
                # result_3 是浮点数
                result_3 = float(parts[5])
                
                # 格式化输出（十六进制带 0x 前缀，浮点数原样）
                print(f"{result_1:#08x} {result_2:#02x} {result_3}")
                
            except ValueError as e:
                print(f"错误：第 {line_num} 行解析失败: {line} | 错误: {e}")
                continue

# 调用函数并处理数据
input_file = '0x1014190f.txt'  # 替换为你的文件名
process_data(input_file)
