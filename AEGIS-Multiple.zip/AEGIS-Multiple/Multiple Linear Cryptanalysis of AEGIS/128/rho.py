import math

def read_data(input_file):
    rho = 0
    with open(input_file, 'r') as infile:
        for line in infile:
            t = line.strip()  
            c = float(t)  
            rho += (2 ** c) ** 2  
    print(math.log2(rho))  

input_file = "rho.txt"
read_data(input_file)
