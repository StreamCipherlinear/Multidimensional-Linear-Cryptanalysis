import struct

def process_data(input_file):
    with open(input_file, 'r') as f:
        for line in f:
            # 读取每一行的数据并拆分，使用制表符('\t')作为分隔符
            parts = line.split('\t')
            
            # 提取十六进制数据和浮动型数据，前五个元素是十六进制，最后一个是浮动型数据
            hex_data = [int(parts[i], 16) for i in range(5)]  # 提取前五个十六进制数据
            
            # 处理浮动型数据，防止出现错误
            try:
                float_data = float(parts[5].strip())  # 去除可能的多余空格
            except ValueError:
                print(f"无法转换浮动型数据: {parts[5]}，跳过此行数据")
                continue  # 如果无法转换，跳过此行

            # 提取第二到第五个十六进制数据
            a, b, c, d = hex_data[1:5]
            
            # 计算第一个输出数据
            result_1 = a ^ (b << 8) ^ (c << 16) ^ (d << 24)
            
            # 第一个十六进制数据
            result_2 = hex_data[0]
            
            # 浮动型数据
            result_3 = float_data
            
            # 输出结果
            print(f"{result_1:#010x} {result_2:#010x} {result_3}")

# 调用函数并处理数据
input_file = 'DATA.txt'  # 输入文件名，根据实际情况修改
process_data(input_file)
