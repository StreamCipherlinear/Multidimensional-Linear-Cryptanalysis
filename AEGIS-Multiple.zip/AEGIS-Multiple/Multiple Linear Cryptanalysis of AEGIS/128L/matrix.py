import numpy as np
import re

# 将十六进制字符串转换为二进制字符串
def hex_to_bin(hex_str):
    return bin(int(hex_str, 16))[2:].zfill(32) 

def read_data(input_file):
    data = []
    hex_pattern = re.compile(r'0x[0-9a-fA-F]+')  # 匹配十六进制数
    
    with open(input_file, 'r') as infile:
        for line in infile:
            # 使用正则表达式查找所有十六进制数
            hex_values = hex_pattern.findall(line.strip())
            if not hex_values:
                continue
                
            bin_values = ''.join(hex_to_bin(h) for h in hex_values)
            data.append([int(bit) for bit in bin_values])
    
    return data

# 判断矩阵的秩是否达到目标秩，并记录线性无关的行
def find_rows_for_target_rank(data, target_rank):
    matrix = []
    row_indices = []
    current_rank = 0  # 当前矩阵的秩
    
    for i, row in enumerate(data):
        matrix.append(row)
        np_matrix = np.array(matrix)
        
        # 检查当前矩阵的秩
        new_rank = np.linalg.matrix_rank(np_matrix)
        
        # 如果秩增加了，记录该行
        if new_rank > current_rank:
            current_rank = new_rank
            row_indices.append(i + 1)  # 存储行号（从1开始）
        
        # 如果已经达到目标秩，直接返回结果
        if current_rank == target_rank:
            return row_indices
    
    return None

# 主函数：将数据转换为矩阵并判断秩
def convert_to_matrix(input_file, target_rank):
    data = read_data(input_file)
    row_indices = find_rows_for_target_rank(data, target_rank)
    
    if row_indices is not None:
        # 输出组成矩阵的行向量的行号，且保证总和最小
        print(f"满足秩要求的矩阵由以下行向量组成，序号总和最小：{row_indices}")
        print(f"这些行的序号总和为：{sum(row_indices)}")
    else:
        print(f"未能找到满足秩 {target_rank} 的矩阵。")

# 输入文件路径和目标秩
input_file = 'output.txt'  # 你可以根据实际情况修改文件路径
target_rank = 45  # 目标秩

convert_to_matrix(input_file, target_rank)
