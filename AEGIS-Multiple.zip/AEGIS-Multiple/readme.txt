1. Step 1.cpp -- Step 1 mentioned in Section 3
2. Bytewise -- Step 2 mentioned in Section 3
3. summary.cpp -- Select linear approximations with high correlations
4. matrix.py -- Select linearly independent linear approximations
5. rho.py -- compute the SEI